# SHEIN product data: free sample, United States, 2026-11-11

10,000 random products from SHEIN's United States catalogue, taken from a full snapshot of
**21,389,348 products** on 2026-11-11. The sample covers 22 of the 23 top-level
categories and 1,561 leaf categories, in proportion to the catalogue.

Files: `shein_us_sample_10k_2026-11-11.csv`, `shein_us_sample_10k_2026-11-11.parquet`, `shein_us_sample_10k_2026-11-11.jsonl` (the same rows), `schema.json`.

**The full dataset** (21,389,348 products, every category) and **other countries**: [votiakov.com/shein-data](https://votiakov.com/shein-data/)

## Fields

| Field | Type | Description |
|---|---|---|
| `product_id` | string | SHEIN product ID (goods ID). Unique per row. The same ID is the same product in every country. |
| `sku` | string | SHEIN SKU code of this colour variant. |
| `spu` | string | SHEIN SPU code shared by all colour variants of a product. |
| `title` | string | Product title as shown to shoppers. |
| `product_url` | string | Product page on the country's SHEIN storefront. |
| `country` | string | ISO country code of the storefront, e.g. GB = United Kingdom, DE = Germany. |
| `currency` | string | ISO currency of the prices. |
| `price` | number | Selling price in local currency, as shown to shoppers (UK and EU: incl. VAT; US: before sales tax). |
| `price_display` | string | Selling price as displayed, with currency symbol. |
| `original_price` | number | Crossed-out (reference) price in local currency. |
| `original_price_display` | string | Crossed-out price as displayed. |
| `discount_pct` | number | 1 - price / original_price, rounded to 4 decimals; 0 when there is no crossed-out price above the price. |
| `price_usd` | number | Selling price converted to US dollars. |
| `top_category` | string | Top-level category name, e.g. Women Apparel. |
| `category` | string | Leaf category name, e.g. Women Mini Dresses. |
| `category_path` | string | Full category path from top level to leaf, separated by ' > '. |
| `category_id` | string | Leaf category ID. |
| `in_stock` | boolean | False when the product is shown as sold out. |
| `stock_indicator` | integer | Stock as shown to shoppers: exact count below 10, 999 = 10 or more; empty when not reported. |
| `review_count` | integer | Number of reviews; 1001 means 1,000 or more. |
| `rating` | number | Average star rating (1–5); empty when the product has no reviews. |
| `color_count` | integer | Number of colour variants offered. |
| `image_url` | string | Main product image URL. |
| `image_urls` | list of strings | All product image URLs (in CSV: separated by '|'). |
| `image_count` | integer | Number of product images. |
| `seller_store_id` | string | ID of the seller storefront that lists the product. |
| `created_date` | date | Date the product was created. |
| `collected_at` | timestamp | When this record was collected, with its UTC offset. |

## Notes

- One row per product (colour variant). `product_id` is the same product in every SHEIN country, so country datasets join on it.
- Prices are what shoppers in the United States see, in local currency, before sales tax.
- `review_count` is capped at 1001, which means 1,000 or more. `stock_indicator` is exact below 10; 999 means 10 or more; it is empty for every product in this snapshot.
- `rating` is empty for products without reviews.
- Image URLs are links to SHEIN's image CDN. No image files are included.
- Independent data. Not affiliated with, endorsed by or sponsored by SHEIN. SHEIN is a trademark of its owner.

## Terms

Free to use for evaluation, research and journalism, with attribution to votiakov.com/shein-data.
Not for resale or redistribution as a dataset. For commercial use and the full data, get a licence at
[votiakov.com/shein-data](https://votiakov.com/shein-data/).
